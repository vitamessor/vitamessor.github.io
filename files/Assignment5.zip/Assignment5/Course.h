/* Course.h
	Assignment Title: Lab 5
	Author: Elizabeth Ozimek-Newman
            Alex Shumate
	Date: 7/29/14
	Class: COP 3502C
	Purpose: Header file for Course.cpp
*/
#ifndef COURSE_H_
#define COURSE_H_

#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <cstring>
#include <iostream>

using namespace std;

typedef unsigned int uint;

class Course{
private:
    string courseName;
    uint numberCredits;

public:
    Course(string courseName = "", uint numberCredits = 0);
    virtual ~Course();
    void setCourseName(string);
    string getCourseName();
    void setNumberCredits(uint);
    uint getNumberCredits();
    friend ostream& operator<<(ostream &out, Course &c);
};


#endif // COURSE_H_
