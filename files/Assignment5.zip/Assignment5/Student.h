/* Student.h
	Assignment Title: Lab 5
	Author: Elizabeth Ozimek-Newman
            Alex Shumate
	Date: 7/29/14
	Class: COP 3502C
	Purpose: Header file for Student.cpp
*/

#ifndef STUDENT_H_
#define STUDENT_H_

#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <cstring>
#include <iostream>

using namespace std;

typedef unsigned int uint;

class Student{
private:
    uint pid;
    string name;
    uint academicYear;

public:
    Student(uint pid = 0, string name = "", uint acedemicYear = 0);
    virtual ~Student();
    void setPID(uint);
    uint getPID();
    void setName(string);
    string getName();
    void setAcademicYear(uint);
    uint getAcademicYear();
    friend ostream& operator<<(ostream &out, Student &s);


};


#endif /* STUDENT_H_ */
