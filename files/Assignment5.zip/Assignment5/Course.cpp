/* Student.h
	Assignment Title: Lab 5
	Author: Elizabeth Ozimek-Newman
            Alex Shumate
	Date: 7/29/14
	Class: COP 3502C
	Purpose: Defines the constructor, deconstructor, friend operator, and the setters and getters for courseName and numberCredits
*/
#include "Course.h"


//constructor for Course
Course::Course(string courseName, uint numberCredits){
    this->courseName = courseName;
    this->numberCredits = numberCredits;
}

//deconstructor for Course
Course::~Course(){
    courseName = "";
    numberCredits = 0;
}

//Getter and Setter for courseName
void Course::setCourseName(string courseName){
    this->courseName = courseName;
}
string Course::getCourseName(){
    return courseName;
}

//Getter and Setter for numberCredits
void Course::setNumberCredits(uint numberCredits){
    this->numberCredits = numberCredits;
}
uint Course::getNumberCredits(){
    return numberCredits;
}

ostream& operator<<(ostream &out, Course &c)
{
    out << "(" << c.courseName << ", " << c.numberCredits <<")";
    return out;
}
