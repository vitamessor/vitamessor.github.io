/* Student.h
	Assignment Title: Lab 5
	Author: Elizabeth Ozimek-Newman
            Alex Shumate
	Date: 7/29/14
	Class: COP 3502C
	Purpose: Defines the constructor, deconstructor, friend operator, and the setters and getters for pid, name, and acedemicYear
*/
#include "Student.h"


Student::Student(uint pid, string name, uint acedemicYear){
    this->pid = pid;
    this->name = name;
    this->academicYear = acedemicYear;
}

//Destrcutor for student
Student::~Student(){
    pid = 0;
    name = "";
    academicYear = 0;
}

//Getter and Setter for PID
void Student::setPID(uint pid){
    this->pid = pid;
}

uint Student::getPID(){
    return pid;
}

//Getter and Setter for name
void Student::setName(string name){
    this->name = name;
}

string Student::getName(){
    return name;
}

//Getter and Setter for academicYear
void Student::setAcademicYear(uint academicYear){
    this->academicYear = academicYear;
}

uint Student::getAcademicYear(){
    return academicYear;
}
ostream& operator<<(ostream &out, Student &s)
{
    out << "(" << s.pid << ", " << s.name << ", " << s.academicYear << ")";
    return out;
}
