/* main.cpp
	Assignment Title: Lab 5
	Author: Elizabeth Ozimek-Newman
            Alex Shumate
	Date: 7/29/14
	Class: COP 3502C
	Purpose: Main file to implement the Student and Course headers and to test the other functions that add students and courses to the hashtables
*/


#include <vector>
#include <map>
#include "Student.h"
#include "Course.h"

void createStudent(map<string, Student>);
Course createCourse();
void addCourse(Student, Course);
void printStudents();

//MAIN FUNCTION
int main(void){
    map<string, Student> students;
    map<int, vector<Course> > courses;
    //createStudent(students);
   /* for(map<string, Student>::iterator it = students.begin(); it != students.end(); it++){
        cout << "\"" << it->first << "\" \n\t" << it->second << "\t" << endl;
    }*/
    return 0;
}

void createStudent(map<string, Student> &students){
    //prompt for the data of a new student (read from keyboard) and add the new student to the map database,
    // if it is not already there. You can assume that the name will be unique.
    uint pid, acedemicYear;
    string name;
    cout << "\nPlease enter the new student's PID\n" << endl;
    cin >> pid;
    cout << "\nPlease enter the new student's name\n" << endl;
    cin >> name;
    cout << "\nPlease enter the new student's acedemic year\n" << endl;
    cin >> acedemicYear;
    students[name]= Student(pid, name, acedemicYear);
}

Course createCourse(){
    //!creates a new course with the information from keyboard, you can store all the courses in a vector

}

void addCourse(Student, Course){
    //!add a course as one of the courses a student has taken
}


void printStudents(){
    //!prints the list of students and all the courses that the student has taken
    //Below is sort of a theory for printing it out but idk how to do it yet
    /*for (std::map<K,V>::iterator it = theMap.begin(); it != theMap.end(); it++) { // iterate over the entries
    K key = it->first;  // Get the key
    V value = it->second;  // Get the value
    std::cout << "(" << key << "," << value << ")" << std::endl;  */
    /*for(map<string, Student>::iterator it1 = students.begin(); it1 != students.end(); it1++){
        cout << "\"" << students->first
    }*/

}
